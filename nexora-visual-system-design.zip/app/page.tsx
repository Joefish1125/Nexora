import NexoraLanding from '@/components/nexora-landing'

export default function Page() {
  return <NexoraLanding />
}
