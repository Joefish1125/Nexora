'use client'

import { useState } from 'react'

const flowNodes = ['Website', 'Phone', 'Social', 'Forms']
const networkNodes = ['Website', 'Phone', 'Customers', 'CRM', 'Email', 'Scheduling', 'Sales', 'Team', 'Data', 'Other tools']

function BrandMark() {
  return <span className="brand-mark" aria-hidden="true"><i /><i /><i /></span>
}

function FlowMap() {
  return (
    <div className="flow-map" aria-label="Customer flow from inbound channels through Nexora to action" role="img">
      <div className="flow-column inbound">
        {flowNodes.map((node, index) => <div className="flow-node muted-node" key={node}><span className="status-dot" />{node}<small>{index === 0 ? 'discover' : index === 1 ? 'respond' : index === 2 ? 'engage' : 'capture'}</small></div>)}
      </div>
      <svg className="flow-lines" viewBox="0 0 620 300" preserveAspectRatio="none" aria-hidden="true">
        <path className="line-muted" d="M92 38 C150 38 150 145 230 145" />
        <path className="line-muted" d="M92 112 C150 112 150 145 230 145" />
        <path className="line-active" d="M92 186 C150 186 150 155 230 155" />
        <path className="line-active" d="M92 260 C150 260 150 160 230 160" />
        <path className="line-active main-line" d="M290 150 H390" />
        <path className="line-active" d="M450 150 C500 150 500 78 570 78" />
        <path className="line-active" d="M450 150 C500 150 500 222 570 222" />
        <circle className="flow-particle p1" r="3" cy="150" cx="300" />
        <circle className="flow-particle p2" r="3" cy="150" cx="500" />
      </svg>
      <div className="flow-core"><span className="core-pulse" /><strong>NEXORA</strong><small>orchestration layer</small></div>
      <div className="flow-column outcomes"><div className="flow-node active-node"><span className="status-dot" />CRM<small>organize</small></div><div className="flow-node active-node"><span className="status-dot" />Follow-up<small>automate</small></div><div className="flow-node action-node"><span className="status-dot" />Action<small>move forward</small></div></div>
    </div>
  )
}

function BuiltAroundNetwork() {
  const [active, setActive] = useState('Website')
  return <div className="network-shell">
    <svg className="network-svg" viewBox="0 0 800 560" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
      <defs><filter id="blue-glow"><feGaussianBlur stdDeviation="5" result="blur" /><feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge></filter></defs>
      {networkNodes.map((node, index) => {
        const angle = (index / networkNodes.length) * Math.PI * 2 - Math.PI / 2
        const x = 400 + Math.cos(angle) * 285
        const y = 280 + Math.sin(angle) * 205
        const isActive = active === node
        return <g key={node} className={isActive ? 'network-link active' : 'network-link'}><line x1="400" y1="280" x2={x} y2={y} /><circle cx={x} cy={y} r={isActive ? 5 : 3} filter={isActive ? 'url(#blue-glow)' : undefined} /></g>
      })}
    </svg>
    <button className="network-core" onClick={() => setActive('Nexora')} aria-label="Nexora central system, active"><span className="core-pulse" /><strong>NEXORA</strong><small>your connected system</small></button>
    {networkNodes.map((node, index) => {
      const angle = (index / networkNodes.length) * Math.PI * 2 - Math.PI / 2
      const x = 50 + Math.cos(angle) * 38
      const y = 50 + Math.sin(angle) * 37
      return <button key={node} className={`orbit-node ${active === node ? 'selected' : ''}`} style={{ left: `${x}%`, top: `${y}%` }} onClick={() => setActive(node)} onMouseEnter={() => setActive(node)}><span className="status-dot" />{node}</button>
    })}
    <div className="network-readout"><span className="status-dot" /> {active === 'Nexora' ? 'All systems connected' : `${active} connected to Nexora`}<b>LIVE</b></div>
  </div>
}

export default function NexoraLanding() {
  return <main className="nexora-site">
    <header className="site-nav"><a className="wordmark" href="#top"><BrandMark />NEXORA</a><nav aria-label="Main navigation"><a href="#systems">Systems</a><a href="#approach">Our approach</a><a href="#built-around-you">Built around you</a></nav><a className="nav-cta" href="#contact">Start a conversation <span>↗</span></a></header>
    <section className="hero section-grid" id="top"><div className="hero-copy"><p className="eyebrow"><span className="eyebrow-line" />CUSTOMER FLOW SYSTEMS</p><h1>Turn customer<br />interest into <em>action.</em></h1><p className="hero-lede">Nexora connects the systems behind your business, so every customer gets a clear next step — and your team gets more time to do the work that matters.</p><a className="primary-cta" href="#contact">Show us your process <span>→</span></a><p className="hero-note"><span className="status-dot" />Built for the way your business already works.</p></div><div className="hero-visual"><div className="visual-label">SYSTEM STATUS <span><i />OPERATIONAL</span></div><FlowMap /></div></section>
    <section className="statement section-grid" id="systems"><div className="statement-number">01 <span>/</span> 03</div><div><p className="eyebrow">THE PROBLEM</p><h2>Good businesses don&apos;t lose customers.<br /><em>They lose the thread.</em></h2></div><p className="section-copy">A message lives in one inbox. A lead waits in a spreadsheet. A follow-up depends on someone remembering. We find the gaps between your systems — then build the bridge.</p></section>
    <section className="before-after" id="approach"><div className="split-panel disconnected"><p className="eyebrow">BEFORE NEXORA</p><h3>Disconnected by default.</h3><div className="mini-flow"><span>Website</span><i /> <span>Email</span><i /><span>Staff</span></div><p>Information moves, but it doesn&apos;t arrive where it needs to be.</p></div><div className="split-panel connected"><p className="eyebrow">AFTER NEXORA</p><h3>Connected with intent.</h3><div className="mini-flow"><span>Website</span><i className="blue" /> <strong>NEXORA</strong><i className="blue" /><span>Action</span></div><p>One clear flow from first signal to next best action.</p></div></section>
    <section className="built-section" id="built-around-you"><div className="built-heading"><p className="eyebrow">BUILT AROUND YOU</p><h2>Your business has<br />its own customer flow.<br /><em>Your system should too.</em></h2><p>We don&apos;t force your business into a prebuilt workflow. We understand how customers move through your business, then connect the systems around that process.</p></div><BuiltAroundNetwork /><div className="built-footer"><span>Your customers. Your process. Your tools.</span><strong>One connected system.</strong></div></section>
    <section className="final-cta" id="contact"><div className="cta-grid" /><p className="eyebrow">READY WHEN YOU ARE</p><h2>Make the next step<br /><em>obvious.</em></h2><p>Tell us where your process gets stuck. We&apos;ll show you what connected could look like.</p><a className="primary-cta" href="mailto:hello@nexora.systems">Show us your process <span>→</span></a><footer><a className="wordmark" href="#top"><BrandMark />NEXORA</a><span>Systems for the way business moves.</span><span>© 2026 Nexora</span></footer></section>
  </main>
}
